func addtwo (a: Int, b: Int) -> Int {
var sum = 0
sum = a + b

return sum
}
    var Sumtotal = addtwo(a: 7, b: 34)
